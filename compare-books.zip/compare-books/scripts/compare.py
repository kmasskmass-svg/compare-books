#!/usr/bin/env python3
"""مقارنة كتاب أساس بكتاب أو أكثر.
python3 compare.py --base base.jsonl --other A=a.jsonl --other B=b.jsonl --out results.json
  [--field fiqh|hadith|nahw|general] [--t-high 0.70] [--t-low 0.35] [--sections map.json]
--sections: ملف JSON اختياري يربط عنوان قسم في الأساس بقائمة عناوين أقسام في الكتاب الآخر لتضييق البحث.
المخرجات: results.json (لكل وحدة من الأساس: أفضل موضع وبديلان ودرجة وحال آلية) و review.tsv (ما دون الحد الأدنى للمراجعة)."""
import json,math,collections,re,argparse
from norm import stem,nw
MARK={'fiqh':r'روايت|وعنه|وجه[اي]ن|الوجهين|وقيل|ويحتمل|يحتمل|احتمال|يتخرج|في أصح|في أظهر|ظاهر المذهب|ظاهر كلامه|عند القاضي|عند أبي|وقال أصحابنا|اختاره|قولان|القولين|والأصح|والصحيح|وفي قول',
      'hadith':r'وقيل|وفيه نظر|اختلف|قولان|والراجح|ورجح',
      'nahw':r'وقيل|مذهب البصريين|الكوفيين|خلافا|وأجاز|ومنع|قولان',
      'general':r'وقيل|قولان|اختلف|والراجح|والصحيح'}
def load(fn): return [json.loads(l) for l in open(fn,encoding='utf-8')]
def bg(t): return set(zip(t,t[1:]))
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--base'); ap.add_argument('--other',action='append'); ap.add_argument('--out')
    ap.add_argument('--field',default='general'); ap.add_argument('--t-high',type=float,default=0.70); ap.add_argument('--t-low',type=float,default=0.35)
    ap.add_argument('--sections'); ap.add_argument('--window',type=int,default=5)
    a=ap.parse_args()
    B=[u for u in load(a.base) if not u['head']]
    O={k:load(v) for k,v in (x.split('=',1) for x in a.other)}
    smap=json.load(open(a.sections,encoding='utf-8')) if a.sections else {}
    df=collections.Counter();N=0
    for U in O.values():
        for u in U:
            if u['head']: continue
            N+=1; df.update(set(u['toks']))
    idf=lambda t: math.log((N+1)/(df.get(t,0)+1))+0.2
    MK=re.compile(MARK.get(a.field,MARK['general']))
    inv={k:collections.defaultdict(set) for k in O}
    for k,U in O.items():
        for j,u in enumerate(U):
            if not u['head']:
                for t in set(u['toks']): inv[k][t].add(j)
    res=[]
    for bu in B:
        zt=bu['toks']; zs=set(zt); zb=bg(zt); tw=sum(idf(t) for t in zs) or 1
        r=dict(i=bu['i'],t=bu['t'],pg=bu['pg'],sec=bu['sec'],m={})
        for k,U in O.items():
            allowed=None
            if bu['sec'] in smap: allowed=set(smap[bu['sec']].get(k,[]))
            score=collections.Counter()
            for t in zs:
                for j in inv[k].get(t,()):
                    if allowed is None or U[j]['sec'] in allowed: score[j]+=idf(t)
            cands=[];seen=set()
            for anc,_ in score.most_common(25):
                for s0 in range(max(0,anc-a.window+1),anc+1):
                    for L in range(1,a.window+1):
                        e=s0+L
                        if e-1<anc or e>len(U) or (s0,e) in seen: continue
                        if any(U[x]['head'] for x in range(s0,e)): continue
                        seen.add((s0,e)); toks=[t for x in range(s0,e) for t in U[x]['toks']]; st=set(toks)
                        rec=sum(idf(t) for t in zs&st)/tw; br=len(zb&bg(toks))/max(1,len(zb))
                        pr=sum(idf(t) for t in st&zs)/max(1e-9,sum(idf(t) for t in st))
                        cands.append((0.5*rec+0.4*br+0.1*pr,s0,e))
            cands.sort(reverse=True); top=[]
            for c in cands:
                if all(c[2]<=t[1] or c[1]>=t[2] for t in top): top.append(c)
                if len(top)==3: break
            def pk(c):
                sc,s0,e=c; txt=' '.join(U[x]['t'] for x in range(s0,e))
                return dict(sc=round(sc,3),s0=s0,e=e,pg=U[s0]['pg'],sec=U[s0]['sec'],t=txt)
            tops=[pk(c) for c in top]
            if not tops: st='N'; best=None
            else:
                best=tops[0]; sc=best['sc']
                hasmk=bool(MK.search(best['t'])) and len(zs & set(t for x in range(best['s0'],best['e']) for t in U[x]['toks']))>=2
                st='R' if sc<a.t_low else ('K' if hasmk else ('T' if sc>=a.t_high else 'Q'))
            r['m'][k]=dict(st=st,best=best,alt=tops[1:])
        res.append(r)
    json.dump(dict(others=list(O),field=a.field,res=res),open(a.out,'w',encoding='utf-8'),ensure_ascii=False)
    with open(a.out.replace('.json','')+'_review.tsv','w',encoding='utf-8') as f:
        f.write('id\tbook\tbase_text\tcand1\tcand2\tcand3\tdecision\n')
        for r in res:
            for k,m in r['m'].items():
                if m['st']=='R':
                    c=[m['best']]+m['alt']; c+= [None]*(3-len(c))
                    f.write('\t'.join([str(r['i']),k,r['t'][:300]]+[(x['t'][:250]+f" (ص {x['pg']})") if x else '' for x in c]+[''])+'\n')
    cnt={k:collections.Counter(r['m'][k]['st'] for r in res) for k in O}
    print(json.dumps(cnt,ensure_ascii=False))
if __name__=='__main__': main()
