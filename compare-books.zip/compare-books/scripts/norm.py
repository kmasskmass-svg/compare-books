import re
TASH=re.compile('[ً-ْٰـ]')
def nw(w):
    w=TASH.sub('',w)
    w=re.sub('[إأآٱ]','ا',w); w=w.replace('ى','ي').replace('ة','ه').replace('ؤ','و').replace('ئ','ي')
    return re.sub(r'[^ء-يa-zA-Z0-9]','',w)
PRE=('وبال','فبال','وال','فال','بال','كال','لل','ال','و','ف','ب')
def stem(w):
    w=nw(w)
    if len(w)<2: return w
    for p in PRE:
        if w.startswith(p) and len(w)-len(p)>=3: w=w[len(p):];break
    if len(w)>4 and w.endswith(('ها','هم','ان','ين','ون','ات')): w=w[:-2]
    elif len(w)>3 and w.endswith(('ه','ي')): w=w[:-1]
    return w
