#!/usr/bin/env python3
"""استخراج نص كتاب إلى وحدات (عبارات) مع رقم الصفحة.
الاستعمال: python3 extract.py INPUT OUT.jsonl [--name اسم]
--unit sentence: يقسم على النقطة والفاصلة المنقوطة والنقطتين فقط (يناسب الكتاب الأساس)؛ والافتراضي clause يقسم على الفاصلة أيضًا.
INPUT: ملف pdf أو docx أو txt، أو ملف بصيغة الشاملة: سطر '@@page_id|printed' ثم النص.
في txt العادي تفصل الصفحات بسطر '@@رقم'، وإلا عُدّ كله صفحة ١."""
import sys,re,json,subprocess,os
from norm import nw,stem
def pages_of(fn):
    ext=os.path.splitext(fn)[1].lower()
    if ext=='.pdf':
        n=int(re.search(r'Pages:\s+(\d+)',subprocess.run(['pdfinfo',fn],capture_output=True,text=True).stdout).group(1))
        for p in range(1,n+1):
            t=subprocess.run(['pdftotext','-layout' if '--layout' in sys.argv else '-raw','-f',str(p),'-l',str(p),fn,'-'],capture_output=True,text=True).stdout
            yield str(p),t
    elif ext=='.docx':
        import docx
        d=docx.Document(fn); buf=[]; pg=1
        for para in d.paragraphs:
            if 'w:br w:type="page"' in para._p.xml or 'lastRenderedPageBreak' in para._p.xml:
                if buf: yield str(pg),'\n'.join(buf); buf=[]; pg+=1
            buf.append(para.text)
        if buf: yield str(pg),'\n'.join(buf)
    else:
        cur='1';buf=[]
        for ln in open(fn,encoding='utf-8'):
            m=re.match(r'@@(\d+)(?:\|(\S+))?',ln)
            if m:
                if buf: yield cur,'\n'.join(buf)
                cur=m.group(2) or m.group(1); buf=[]
            else: buf.append(ln.rstrip('\n'))
        if buf: yield cur,'\n'.join(buf)
HEAD=re.compile(r'^(كتاب|باب|فصل|الباب|الفصل|المبحث|المطلب|الكتاب)\b')
def main():
    src,out=sys.argv[1],sys.argv[2]
    units=[];sec=''
    TASH=re.compile('[ً-ْٰـ]')
    for pg,text in pages_of(src):
        text=TASH.sub('',text)
        text=re.sub(r'\(\s*[0-9٠-٩]+\s*\)','',text)   # أرقام الحواشي
        for line in text.split('\n'):
            line=line.strip()
            if not line or re.fullmatch(r'[\d٠-٩\s\-–]+',line): continue
            if HEAD.match(line) and len(line)<80:
                sec=line; units.append(dict(t=line,pg=pg,sec=sec,head=1)); continue
            SPL=r'(?<=[.؛:?؟!])\s+' if '--unit' in sys.argv and sys.argv[sys.argv.index('--unit')+1]=='sentence' else r'(?<=[.؛:،?؟!])\s+'
            for part in re.split(SPL,line):
                toks=[stem(w) for w in part.split() if nw(w)]
                if toks: units.append(dict(t=part,pg=pg,sec=sec,head=0,toks=toks))
    # ضم ما انقطع عند آخر السطر
    merged=[]
    for u in units:
        if merged and not u['head'] and not merged[-1]['head'] and not re.search(r'[.؛:،?؟!»")\-]\s*$',merged[-1]['t']) and len(merged[-1]['toks'])<6:
            merged[-1]['t']+=' '+u['t']; merged[-1]['toks']+=u['toks']
        else: merged.append(u)
    with open(out,'w',encoding='utf-8') as f:
        for i,u in enumerate(merged): u['i']=i; f.write(json.dumps(u,ensure_ascii=False)+'\n')
    print(out,len(merged),'وحدة')
if __name__=='__main__': main()
