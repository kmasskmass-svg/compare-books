#!/usr/bin/env python3
"""إخراج النتائج: كتاب كامل، أو تقرير مختصر، أو ملخص للمحادثة.
python3 report.py results.json --mode full|short|chat --base-name "زاد المستقنع" --names "A=المقنع" --names "B=الوجيز"
   --title "..." --author "..." [--credit "..."] [--out out_dir] [--pdf]
يحتاج: python-docx, matplotlib (ويفضل arabic-reshaper و python-bidi إن ظهرت الحروف مقطعة)، و LibreOffice لتحويل PDF."""
import json,argparse,collections,os,subprocess,statistics
ap=argparse.ArgumentParser()
ap.add_argument('results'); ap.add_argument('--mode',default='short'); ap.add_argument('--base-name',default='الكتاب الأساس')
ap.add_argument('--names',action='append',default=[]); ap.add_argument('--title',default='مقارنة بين الكتب'); ap.add_argument('--author',default='')
ap.add_argument('--credit',default=''); ap.add_argument('--out',default='out'); ap.add_argument('--pdf',action='store_true')
ap.add_argument('--method',default='')
a=ap.parse_args()
D=json.load(open(a.results,encoding='utf-8')); R=D['res']; K=D['others']
NM={k:k for k in K}; NM.update(dict(x.split('=',1) for x in a.names))
CAT=['T','Q','K','M','N','R']; CN={'T':'متطابق','Q':'متقارب','K':'حكى خلافًا','M':'مخالف','N':'غير مذكور','R':'لم يراجع'}
SYM={'T':'ت','Q':'ق','K':'خ','M':'م','N':'—','R':'؟'}
COL={'T':'#1b7a52','Q':'#5fbf8a','K':'#e0a526','M':'#c4402f','N':'#9b9b9b','R':'#d0d0d0'}
AR=lambda s: str(s).translate(str.maketrans('0123456789.','٠١٢٣٤٥٦٧٨٩٫'))
P=lambda x,n: AR(f'{x*100/n:.1f}')+'٪' if n else '—'
n=len(R); agree=lambda s: s in 'TQ'
st=lambda r,k: r['m'][k]['st']
cnt={k:collections.Counter(st(r,k) for r in R) for k in K}
allag=sum(1 for r in R if all(agree(st(r,k)) for k in K))
noneag=sum(1 for r in R if not any(agree(st(r,k)) for k in K))
sim={k:statistics.mean(min(1,r['m'][k]['best']['sc']) if r['m'][k]['best'] else 0 for r in R)*100 for k in K}
secs=list(dict.fromkeys(r['sec'] or '—' for r in R))
os.makedirs(a.out,exist_ok=True)
if a.mode=='chat':
    print(f'## نتائج مقارنة «{a.base_name}» بـ'+'، '.join(f'«{NM[k]}»' for k in K)+f'\n\nعدد وحدات الأساس: {n}\n')
    print('| الحال | '+' | '.join(NM[k] for k in K)+' |\n|---|'+'---|'*len(K))
    for c in CAT:
        if any(cnt[k][c] for k in K): print(f'| {CN[c]} | '+' | '.join(f'{cnt[k][c]} ({cnt[k][c]*100/n:.1f}٪)' for k in K)+' |')
    print(f'\n- وافق الأساسُ الكتبَ كلها في {allag} وحدة ({allag*100/n:.1f}٪)، ولم يوافق أيًّا منها في {noneag} ({noneag*100/n:.1f}٪).')
    for k in K: print(f'- متوسط التشابه اللفظي مع «{NM[k]}»: {sim[k]:.1f}٪')
    raise SystemExit
# ---------- charts
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
for f in ('/root/.fonts/Amiri-Regular.ttf','/usr/share/fonts/truetype/amiri/Amiri-Regular.ttf'):
    if os.path.exists(f): fm.fontManager.addfont(f); plt.rcParams['font.family']='Amiri'
try:
    import arabic_reshaper; from bidi.algorithm import get_display
    SHAPE=os.environ.get('SHAPE')=='1'
except ImportError: SHAPE=False
A=(lambda s: get_display(arabic_reshaper.reshape(str(s)))) if SHAPE else str
def stacked(fn,labels,rows,h):
    fig,ax=plt.subplots(figsize=(9,h)); left=[0]*len(labels)
    for c in CAT:
        v=[r[c] for r in rows]
        if not any(v): continue
        ax.barh(range(len(labels)),v,left=left,color=COL[c],edgecolor='white',height=.6,label=A(CN[c]))
        for i,(l,x) in enumerate(zip(left,v)):
            if x>=6: ax.text(l+x/2,i,AR(f'{x:.0f}'),ha='center',va='center',fontsize=9,color='white' if c in 'TKM' else '#111')
        left=[p+q for p,q in zip(left,v)]
    ax.set_yticks(range(len(labels))); ax.set_yticklabels([A(l) for l in labels]); ax.invert_yaxis(); ax.set_xlim(0,100)
    ax.xaxis.set_major_formatter(lambda x,p: AR(int(x))+'٪'); ax.spines[['top','right']].set_visible(False)
    ax.legend(ncol=5,loc='upper center',bbox_to_anchor=(.5,1.0+1.2/h/2+.08),frameon=False,fontsize=10)
    fig.tight_layout(); fig.savefig(fn,dpi=180); plt.close()
pct=lambda rows,k:{c:sum(1 for r in rows if st(r,k)==c)*100/max(1,len(rows)) for c in CAT}
stacked(f'{a.out}/c1.png',[NM[k] for k in K],[pct(R,k) for k in K],1.4+0.6*len(K))
FIG=[('c1.png','حال وحدات «'+a.base_name+'» في كل كتاب')]
if len(secs)>1 and a.mode=='full':
    for k in K:
        stacked(f'{a.out}/s_{k}.png',secs,[pct([r for r in R if (r['sec'] or '—')==s],k) for s in secs],max(3,0.42*len(secs)+1.5))
fig,ax=plt.subplots(figsize=(9,3))
for k,c in zip(K,['#1F4E3D','#B08D3C','#2a78d6','#6250d6']):
    ax.hist([min(1,r['m'][k]['best']['sc']) if r['m'][k]['best'] else 0 for r in R],bins=20,range=(0,1),histtype='step',lw=2,color=c,label=A(NM[k]))
ax.xaxis.set_major_formatter(lambda x,p: AR(int(x*100))+'٪'); ax.legend(frameon=False); ax.spines[['top','right']].set_visible(False)
ax.set_xlabel(A('درجة التشابه اللفظي')); fig.tight_layout(); fig.savefig(f'{a.out}/c2.png',dpi=180); plt.close()
FIG.append(('c2.png','توزيع درجات التشابه اللفظي'))
# ---------- docx
from docx import Document
from docx.shared import Pt,Cm,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
GREEN=RGBColor(0x1F,0x4E,0x3D); GOLD=RGBColor(0xB0,0x8D,0x3C); FONT='Traditional Arabic'
doc=Document()
for s in doc.sections: s.top_margin=s.bottom_margin=Cm(2.5); s.left_margin=s.right_margin=Cm(2.3)
def rtl_p(p):
    pPr=p._p.get_or_add_pPr(); b=OxmlElement('w:bidi'); pPr.append(b)
def runf(r,size=14,bold=False,color=None):
    r.font.name=FONT; r.font.size=Pt(size); r.bold=bold
    rPr=r._r.get_or_add_rPr(); f=rPr.find(qn('w:rFonts'))
    if f is None: f=OxmlElement('w:rFonts'); rPr.append(f)
    for at in ('w:ascii','w:hAnsi','w:cs'): f.set(qn(at),FONT)
    sz=OxmlElement('w:szCs'); sz.set(qn('w:val'),str(int(size*2))); rPr.append(sz)
    if bold: rPr.append(OxmlElement('w:bCs'))
    rPr.append(OxmlElement('w:rtl'))
    if color: r.font.color.rgb=color
def para(text,size=14,bold=False,color=None,align='j',after=6):
    p=doc.add_paragraph(); rtl_p(p); p.paragraph_format.space_after=Pt(after)
    p.alignment={'j':WD_ALIGN_PARAGRAPH.JUSTIFY,'c':WD_ALIGN_PARAGRAPH.CENTER,'r':WD_ALIGN_PARAGRAPH.RIGHT}[align]
    runf(p.add_run(text),size,bold,color); return p
def head(text,lvl=1):
    p=doc.add_heading(level=lvl); rtl_p(p); p.alignment=WD_ALIGN_PARAGRAPH.RIGHT if lvl>1 else WD_ALIGN_PARAGRAPH.CENTER
    runf(p.add_run(text),22 if lvl==1 else 17,True,GREEN)
def shade(cell,fill):
    tcPr=cell._tc.get_or_add_tcPr(); s=OxmlElement('w:shd'); s.set(qn('w:val'),'clear'); s.set(qn('w:fill'),fill); tcPr.append(s)
def table(hdr,rows,widths=None,size=11):
    t=doc.add_table(rows=1,cols=len(hdr)); t.style='Table Grid'
    tblPr=t._tbl.tblPr; b=OxmlElement('w:bidiVisual'); tblPr.append(b)
    for i,h in enumerate(hdr):
        c=t.rows[0].cells[i]; shade(c,'1F4E3D'); p=c.paragraphs[0]; rtl_p(p); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; runf(p.add_run(h),size,True,RGBColor(255,255,255))
    for ri,row in enumerate(rows):
        cs=t.add_row().cells
        for i,v in enumerate(row):
            p=cs[i].paragraphs[0]; rtl_p(p); p.alignment=WD_ALIGN_PARAGRAPH.CENTER if len(str(v))<14 else WD_ALIGN_PARAGRAPH.RIGHT
            runf(p.add_run(str(v)),size); shade(cs[i],'F6F0E1' if ri%2==0 else 'FBF8F0')
    if widths:
        for row in t.rows:
            for c,w in zip(row.cells,widths): c.width=Cm(w)
    doc.add_paragraph()
# cover
para(a.title,30,True,GREEN,'c',12); para(a.base_name+' مقارنًا بـ'+' و'.join('«'+NM[k]+'»' for k in K),18,True,GOLD,'c',30)
if a.author: para('إعداد',13,False,None,'c',2); para(a.author,18,True,GREEN,'c',4)
if a.credit: para(a.credit,12,False,None,'c',20)
doc.add_page_break()
if a.mode=='full':
    head('المقدمة'); para(f'هذه مقارنة بين «{a.base_name}» و'+'، و'.join('«'+NM[k]+'»' for k in K)+f'، تتبعت فيها {AR(n)} وحدة من وحدات الأساس في '+('كل كتاب منها' if len(K)>1 else 'الكتاب الآخر')+'، وقست درجة التطابق بينها بالأعداد والنسب والرسوم.')
    head('منهج العمل',2)
    for i,s in enumerate([x for x in (a.method.split('||') if a.method else [
        'استُخرج نص الكتب من ملفاتها، وجُرّد من التشكيل وأرقام الحواشي، وقُسّم إلى عبارات مع أرقام صفحاتها.',
        'استُعين في المقارنة والإحصاء بالنموذج الذكي «Claude» من شركة Anthropic، فقورنت كل عبارة من الأساس بعبارات كل كتاب ببرنامج يقيس اشتراك الألفاظ وتتابعها، واختير أقرب موضع لها مع درجة تشابه من صفر إلى مئة.',
        'ما كانت درجته منخفضة روجع موضعًا موضعًا مع أقرب ثلاثة مواضع إليه، وما فوق ذلك صُنّف آليًّا: متطابق إذا بلغ ٧٠٪، ومتقارب فيما دونه، ويُعدّ مما حكى فيه الخلاف إذا ذُكر في الموضع نفسه خلاف.',
        'ثم روجعت النتائج وأُقرّت.']) if x]): para(AR(i+1)+'- '+s)
    head('مصطلحات التصنيف',2)
    table(['الرمز','الحال'],[[SYM[c],CN[c]] for c in 'TQKMN'],[3,6])
    doc.add_page_break()
head('النتائج العامة' if a.mode=='full' else 'النتائج')
rows=[[CN[c]]+[f'{AR(cnt[k][c])} ({P(cnt[k][c],n)})' for k in K] for c in CAT if any(cnt[k][c] for k in K)]
rows.append(['الموافق في الحكم (ت+ق)']+[f'{AR(cnt[k]["T"]+cnt[k]["Q"])} ({P(cnt[k]["T"]+cnt[k]["Q"],n)})' for k in K])
table(['الحال']+[NM[k] for k in K],rows)
para(f'وافق «{a.base_name}» الكتب كلها في {AR(allag)} وحدة ({P(allag,n)})، ولم يوافق أيًّا منها بنصه في {AR(noneag)} وحدة ({P(noneag,n)}). ومتوسط التشابه اللفظي: '+'، '.join(f'مع «{NM[k]}» {AR(f"{sim[k]:.1f}")}٪' for k in K)+'.')
for fn,cap in FIG:
    doc.add_picture(f'{a.out}/{fn}',width=Cm(16)); doc.paragraphs[-1].alignment=WD_ALIGN_PARAGRAPH.CENTER; para('شكل: '+cap,11,True,None,'c',12)
if len(secs)>1:
    head('النتائج في كل قسم',2 if a.mode=='short' else 1)
    for k in K:
        para('مع «'+NM[k]+'»',15,True,GOLD,'r')
        table(['القسم','الوحدات']+[SYM[c] for c in 'TQKMN']+['الموافقة'],
              [[s,AR(len(G))]+[AR(sum(1 for r in G if st(r,k)==c)) for c in 'TQKMN']+[P(sum(1 for r in G if agree(st(r,k))),len(G))] for s in secs for G in [[r for r in R if (r['sec'] or '—')==s]]],[5.5,1.6]+[1.2]*5+[2],size=10)
        if a.mode=='full' and os.path.exists(f'{a.out}/s_{k}.png'):
            doc.add_picture(f'{a.out}/s_{k}.png',width=Cm(16)); doc.paragraphs[-1].alignment=WD_ALIGN_PARAGRAPH.CENTER
head('المواضع المخالفة',2 if a.mode=='short' else 1)
ML=[r for r in R if any(st(r,k)=='M' for k in K)]
if ML: table(['عبارة '+a.base_name]+[NM[k] for k in K],[[f"{r['t']} (ص {AR(r['pg'])})"]+[(f"{r['m'][k]['best']['t']} (ص {AR(r['m'][k]['best']['pg'])})" if st(r,k)=='M' else SYM[st(r,k)]) for k in K] for r in ML],size=10)
else: para('لا توجد مواضع حُكم عليها بالمخالفة.')
if a.mode=='full':
    doc.add_page_break(); head('جدول التتبع'); para('أمام كل وحدة من الأساس صفحتها، ثم حالها ورقم صفحتها في كل كتاب. الرموز: ت متطابق، ق متقارب، خ حكى خلافًا، م مخالف، — غير مذكور.')
    table(['م','العبارة','ص']+[x for k in K for x in (NM[k],'ص')],
        [[AR(i+1),r['t'][:120],AR(r['pg'])]+[x for k in K for x in (SYM[st(r,k)],AR(r['m'][k]['best']['pg']) if r['m'][k]['best'] and st(r,k)!='N' else '—')] for i,r in enumerate(R)],size=9)
    head('الخاتمة'); para('وما كان في هذا العمل من صواب فمن الله وحده، وما كان فيه من خطأ فمن نفسي ومن الشيطان.')
fn=f'{a.out}/{a.title}.docx'; doc.save(fn); print(fn)
if a.pdf:
    subprocess.run(['soffice','--headless','--convert-to','pdf','--outdir',a.out,fn],capture_output=True); print(fn[:-5]+'.pdf')
