---
name: compare-books
description: مقارنة كتابين أو أكثر في أي فن (فقه، حديث، نحو، تفسير…) بقياس التطابق مسألةً مسألة بالنسب والرسوم، من الشاملة أو تراث أو الويب أو ملفات PDF/Word محلية، وإخراجها كتابًا كاملًا أو تقريرًا مختصرًا أو ملخصًا في المحادثة.
---

# مقارنة الكتب (compare-books)

تقارن هذه المهارة كتابًا «أساسًا» بكتاب آخر أو أكثر: تتبّع كل وحدة (مسألة/عبارة) من الأساس في الكتب الأخرى، وتصنّف حالها، ثم تحصي وترسم وتُخرج النتائج.

## ١) اسأل أولًا (AskUserQuestion، سؤال إلى أربعة في رسالة واحدة)
1. **الكتب**: ما الكتاب الأساس؟ وما الكتب المقارَن بها؟ (اسم كل كتاب ومؤلفه، والطبعة إن عرفت).
2. **المصدر** لكل كتاب:
   - المكتبة الشاملة المثبتة على جهاز المستخدم (أدوات `shamela_*` أو `mcp__remote-devices__…shamela_*`).
   - موقع تراث turath.io (أدوات `turath_*` إن وُجدت، وإلا الويب).
   - مصدر آخر يفضله (موقع أو منصة كإثراء): افتحه بالمتصفح أو WebFetch، أو اطلب منه تنزيل الكتاب ملفًا.
   - مجلد محلي فيه الكتب بصيغة PDF أو Word أو نص (عبر أدوات الجهاز، أو يرفعها في المحادثة).
3. **طريقة العرض**: (أ) كتاب كامل منسق: مقدمة ومنهج وإحصاءات ورسوم وجدول تتبع كامل، Word + PDF. (ب) تقرير مختصر Word أو PDF. (ج) ملخص في المحادثة فقط.
4. **الفن ووحدة المقارنة**: الفن (fiqh / hadith / nahw / general) لتحديد ألفاظ «حكاية الخلاف»، ونطاق المقارنة (الكتاب كله أم أبواب معينة)، واسم المُعِدّ وأي سطر دعاء أو إهداء للغلاف.

إن لم يجب المستخدم فاختر: الأساس أول كتاب ذُكر، والعرض (ب)، والفن general.

## ٢) جلب النصوص — حرفيًّا، لا من الذاكرة
- اكتب كل كتاب في ملف نصي بالصيغة: سطر `@@رقم_الصفحة|الرقم_المطبوع` ثم نص الصفحة. احذف الحواشي وكلام المحقق، وأبقِ ما بين المعقوفين من المتن، ولا تصحح إلا الخطأ الطباعي الظاهر (وسجّله).
- الشاملة: حدّد رقم الكتاب (`shamela_resolve`/`shamela_search_books`)، ثم حدود الأبواب من `shamela_get_toc`، ثم `shamela_get_pages_range` بـ count=20 وأكمل من `next_start_page_id`. الكتب الطويلة: انسخ على دفعات واحفظ التقدم في ملف HANDOFF حتى لا يضيع عند ضغط السياق.
- PDF/Word: مرّرها مباشرة إلى `extract.py` (يستعمل pdftotext وpython-docx). إن كان PDF مصورًا بلا نص فأخبر المستخدم واطلب نسخة نصية أو اقترح OCR.
- لا تنسب نصًّا إلى كتاب إلا ما جاء من المصدر فعلًا، ولا تختلق بيانات طبعة أو محقق.

## ٣) التشغيل
السكربتات في `scripts/` من هذه المهارة (إن لم تكن موجودة فاكتبها من «الملحق» آخر الملف بحروفها). تحتاج: Python 3، python-docx، matplotlib، poppler-utils، LibreOffice (للـPDF). ثبّت الناقص بـ pip --break-system-packages.

```bash
S=<مسار scripts>
python3 $S/extract.py base.txt base.jsonl --unit sentence      # الأساس: جمل
python3 $S/extract.py a.pdf a.jsonl                           # الآخر: عبارات أدق
python3 $S/extract.py b.docx b.jsonl
python3 $S/compare.py --base base.jsonl --other A=a.jsonl --other B=b.jsonl --out results.json --field fiqh
```
- اختياري `--sections map.json` لحصر البحث في الأبواب المتقابلة: `{"باب المياه":{"A":["باب المياه"],"B":["باب المياه"]}}` — مفيد جدًّا في الكتب الطويلة.
- الحالات: T متطابق (≥٧٠٪)، Q متقارب، K حكى خلافًا والأساس جزم، M مخالف، N غير مذكور، R تحتاج مراجعة (<٣٥٪).

## ٤) المراجعة — لا تتخطّها
- افتح `results_review.tsv` على دفعات من ٥٠ سطرًا. لكل وحدة اقرأ عبارة الأساس والمرشحين الثلاثة، وابحث في نص الكتاب الآخر عند الشك (grep في ملف الـtxt). احكم: T/Q/K/M/N، ومع رقم المرشح الصحيح إن لم يكن الأول.
- اكتب القرارات في `decisions.txt` بالصيغة `id<TAB>book<TAB>رمز[<TAB>رقم المرشح]` ثم: `python3 $S/apply_review.py results.json decisions.txt`.
- ابحث عن المخالف المخفي في T/Q: استخرج الوحدات التي تختلف فيها ألفاظ الحكم (يجب/يسن/يكره/يحرم/يباح/يصح/يبطل، أو ما يقابلها في الفن) بين الأساس وموضعه، وراجعها وأثبت M حيث يلزم.
- إن كانت الوحدات كثيرة جدًّا فأخبر المستخدم بالعدد قبل البدء، واعرض مراجعة عيّنة إن أراد السرعة، وصرّح بذلك في المنهج.

## ٥) الإخراج
```bash
python3 $S/report.py results.json --mode full|short|chat --base-name "…" --names A="…" --names B="…" \
   --title "…" --author "…" --credit "…" --out out --pdf
```
- `chat`: يطبع جدولًا مختصرًا بالـMarkdown؛ انقله إلى ردك.
- `short`: نتائج عامة + رسمان + جدول الأقسام + المواضع المخالفة.
- `full`: غلاف، مقدمة، منهج، مصطلحات، نتائج، رسوم، أقسام، مخالف، جدول تتبع كامل، خاتمة.
- للكتاب الكامل الفاخر (فهرس بأرقام صفحات، إطارات، زخارف) يمكن البناء بـ docx-js بدل report.py، لكن ابدأ بـ report.py.
- افحص الناتج قبل التسليم: حوّل صفحات من الـPDF إلى صور وانظر إليها (الرسوم العربية: إن ظهرت الحروف مقطعة فشغّل بـ SHAPE=1 بعد تثبيت arabic-reshaper وpython-bidi؛ وإن ظهرت معكوسة فأزل SHAPE).
- سلّم الملفات بـ SendUserFile، وإن طلب المستخدم مجلدًا على جهازه فاكتبها فيه.

## ٦) الأمانة في المنهج
- اكتب المنهج بصيغة المبني للمجهول، وصرّح بأن المقارنة والإحصاء تمّا بالاستعانة بالنموذج الذكي Claude، وأن المستخدم راجع النتائج وأقرّها.
- اذكر حدود الطريقة في تنبيه: التصنيف الآلي قياس للعبارة قبل الحكم، وقسمة الوحدات اجتهادية.
- لا تبنِ نتيجة تاريخية (كأخذ كتاب من آخر) إلا قرينةً إحصائية، وقل ذلك صراحة.
- الرد للمستخدم بلغته (العربية إن كتب بها)، باختصار.

## الملحق: السكربتات

### scripts/norm.py
```python
import re
TASH=re.compile('[ً-ْٰـ]')
def nw(w):
    w=TASH.sub('',w)
    w=re.sub('[إأآٱ]','ا',w); w=w.replace('ى','ي').replace('ة','ه').replace('ؤ','و').replace('ئ','ي')
    return re.sub(r'[^ء-يa-zA-Z0-9]','',w)
PRE=('وبال','فبال','وال','فال','بال','كال','لل','ال','و','ف','ب')
def stem(w):
    w=nw(w)
    if len(w)<2: return w
    for p in PRE:
        if w.startswith(p) and len(w)-len(p)>=3: w=w[len(p):];break
    if len(w)>4 and w.endswith(('ها','هم','ان','ين','ون','ات')): w=w[:-2]
    elif len(w)>3 and w.endswith(('ه','ي')): w=w[:-1]
    return w
```

### scripts/extract.py
```python
#!/usr/bin/env python3
"""استخراج نص كتاب إلى وحدات (عبارات) مع رقم الصفحة.
الاستعمال: python3 extract.py INPUT OUT.jsonl [--name اسم]
--unit sentence: يقسم على النقطة والفاصلة المنقوطة والنقطتين فقط (يناسب الكتاب الأساس)؛ والافتراضي clause يقسم على الفاصلة أيضًا.
INPUT: ملف pdf أو docx أو txt، أو ملف بصيغة الشاملة: سطر '@@page_id|printed' ثم النص.
في txt العادي تفصل الصفحات بسطر '@@رقم'، وإلا عُدّ كله صفحة ١."""
import sys,re,json,subprocess,os
from norm import nw,stem
def pages_of(fn):
    ext=os.path.splitext(fn)[1].lower()
    if ext=='.pdf':
        n=int(re.search(r'Pages:\s+(\d+)',subprocess.run(['pdfinfo',fn],capture_output=True,text=True).stdout).group(1))
        for p in range(1,n+1):
            t=subprocess.run(['pdftotext','-layout' if '--layout' in sys.argv else '-raw','-f',str(p),'-l',str(p),fn,'-'],capture_output=True,text=True).stdout
            yield str(p),t
    elif ext=='.docx':
        import docx
        d=docx.Document(fn); buf=[]; pg=1
        for para in d.paragraphs:
            if 'w:br w:type="page"' in para._p.xml or 'lastRenderedPageBreak' in para._p.xml:
                if buf: yield str(pg),'\n'.join(buf); buf=[]; pg+=1
            buf.append(para.text)
        if buf: yield str(pg),'\n'.join(buf)
    else:
        cur='1';buf=[]
        for ln in open(fn,encoding='utf-8'):
            m=re.match(r'@@(\d+)(?:\|(\S+))?',ln)
            if m:
                if buf: yield cur,'\n'.join(buf)
                cur=m.group(2) or m.group(1); buf=[]
            else: buf.append(ln.rstrip('\n'))
        if buf: yield cur,'\n'.join(buf)
HEAD=re.compile(r'^(كتاب|باب|فصل|الباب|الفصل|المبحث|المطلب|الكتاب)\b')
def main():
    src,out=sys.argv[1],sys.argv[2]
    units=[];sec=''
    TASH=re.compile('[ً-ْٰـ]')
    for pg,text in pages_of(src):
        text=TASH.sub('',text)
        text=re.sub(r'\(\s*[0-9٠-٩]+\s*\)','',text)   # أرقام الحواشي
        for line in text.split('\n'):
            line=line.strip()
            if not line or re.fullmatch(r'[\d٠-٩\s\-–]+',line): continue
            if HEAD.match(line) and len(line)<80:
                sec=line; units.append(dict(t=line,pg=pg,sec=sec,head=1)); continue
            SPL=r'(?<=[.؛:?؟!])\s+' if '--unit' in sys.argv and sys.argv[sys.argv.index('--unit')+1]=='sentence' else r'(?<=[.؛:،?؟!])\s+'
            for part in re.split(SPL,line):
                toks=[stem(w) for w in part.split() if nw(w)]
                if toks: units.append(dict(t=part,pg=pg,sec=sec,head=0,toks=toks))
    # ضم ما انقطع عند آخر السطر
    merged=[]
    for u in units:
        if merged and not u['head'] and not merged[-1]['head'] and not re.search(r'[.؛:،?؟!»")\-]\s*$',merged[-1]['t']) and len(merged[-1]['toks'])<6:
            merged[-1]['t']+=' '+u['t']; merged[-1]['toks']+=u['toks']
        else: merged.append(u)
    with open(out,'w',encoding='utf-8') as f:
        for i,u in enumerate(merged): u['i']=i; f.write(json.dumps(u,ensure_ascii=False)+'\n')
    print(out,len(merged),'وحدة')
if __name__=='__main__': main()
```

### scripts/compare.py
```python
#!/usr/bin/env python3
"""مقارنة كتاب أساس بكتاب أو أكثر.
python3 compare.py --base base.jsonl --other A=a.jsonl --other B=b.jsonl --out results.json
  [--field fiqh|hadith|nahw|general] [--t-high 0.70] [--t-low 0.35] [--sections map.json]
--sections: ملف JSON اختياري يربط عنوان قسم في الأساس بقائمة عناوين أقسام في الكتاب الآخر لتضييق البحث.
المخرجات: results.json (لكل وحدة من الأساس: أفضل موضع وبديلان ودرجة وحال آلية) و review.tsv (ما دون الحد الأدنى للمراجعة)."""
import json,math,collections,re,argparse
from norm import stem,nw
MARK={'fiqh':r'روايت|وعنه|وجه[اي]ن|الوجهين|وقيل|ويحتمل|يحتمل|احتمال|يتخرج|في أصح|في أظهر|ظاهر المذهب|ظاهر كلامه|عند القاضي|عند أبي|وقال أصحابنا|اختاره|قولان|القولين|والأصح|والصحيح|وفي قول',
      'hadith':r'وقيل|وفيه نظر|اختلف|قولان|والراجح|ورجح',
      'nahw':r'وقيل|مذهب البصريين|الكوفيين|خلافا|وأجاز|ومنع|قولان',
      'general':r'وقيل|قولان|اختلف|والراجح|والصحيح'}
def load(fn): return [json.loads(l) for l in open(fn,encoding='utf-8')]
def bg(t): return set(zip(t,t[1:]))
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--base'); ap.add_argument('--other',action='append'); ap.add_argument('--out')
    ap.add_argument('--field',default='general'); ap.add_argument('--t-high',type=float,default=0.70); ap.add_argument('--t-low',type=float,default=0.35)
    ap.add_argument('--sections'); ap.add_argument('--window',type=int,default=5)
    a=ap.parse_args()
    B=[u for u in load(a.base) if not u['head']]
    O={k:load(v) for k,v in (x.split('=',1) for x in a.other)}
    smap=json.load(open(a.sections,encoding='utf-8')) if a.sections else {}
    df=collections.Counter();N=0
    for U in O.values():
        for u in U:
            if u['head']: continue
            N+=1; df.update(set(u['toks']))
    idf=lambda t: math.log((N+1)/(df.get(t,0)+1))+0.2
    MK=re.compile(MARK.get(a.field,MARK['general']))
    inv={k:collections.defaultdict(set) for k in O}
    for k,U in O.items():
        for j,u in enumerate(U):
            if not u['head']:
                for t in set(u['toks']): inv[k][t].add(j)
    res=[]
    for bu in B:
        zt=bu['toks']; zs=set(zt); zb=bg(zt); tw=sum(idf(t) for t in zs) or 1
        r=dict(i=bu['i'],t=bu['t'],pg=bu['pg'],sec=bu['sec'],m={})
        for k,U in O.items():
            allowed=None
            if bu['sec'] in smap: allowed=set(smap[bu['sec']].get(k,[]))
            score=collections.Counter()
            for t in zs:
                for j in inv[k].get(t,()):
                    if allowed is None or U[j]['sec'] in allowed: score[j]+=idf(t)
            cands=[];seen=set()
            for anc,_ in score.most_common(25):
                for s0 in range(max(0,anc-a.window+1),anc+1):
                    for L in range(1,a.window+1):
                        e=s0+L
                        if e-1<anc or e>len(U) or (s0,e) in seen: continue
                        if any(U[x]['head'] for x in range(s0,e)): continue
                        seen.add((s0,e)); toks=[t for x in range(s0,e) for t in U[x]['toks']]; st=set(toks)
                        rec=sum(idf(t) for t in zs&st)/tw; br=len(zb&bg(toks))/max(1,len(zb))
                        pr=sum(idf(t) for t in st&zs)/max(1e-9,sum(idf(t) for t in st))
                        cands.append((0.5*rec+0.4*br+0.1*pr,s0,e))
            cands.sort(reverse=True); top=[]
            for c in cands:
                if all(c[2]<=t[1] or c[1]>=t[2] for t in top): top.append(c)
                if len(top)==3: break
            def pk(c):
                sc,s0,e=c; txt=' '.join(U[x]['t'] for x in range(s0,e))
                return dict(sc=round(sc,3),s0=s0,e=e,pg=U[s0]['pg'],sec=U[s0]['sec'],t=txt)
            tops=[pk(c) for c in top]
            if not tops: st='N'; best=None
            else:
                best=tops[0]; sc=best['sc']
                hasmk=bool(MK.search(best['t'])) and len(zs & set(t for x in range(best['s0'],best['e']) for t in U[x]['toks']))>=2
                st='R' if sc<a.t_low else ('K' if hasmk else ('T' if sc>=a.t_high else 'Q'))
            r['m'][k]=dict(st=st,best=best,alt=tops[1:])
        res.append(r)
    json.dump(dict(others=list(O),field=a.field,res=res),open(a.out,'w',encoding='utf-8'),ensure_ascii=False)
    with open(a.out.replace('.json','')+'_review.tsv','w',encoding='utf-8') as f:
        f.write('id\tbook\tbase_text\tcand1\tcand2\tcand3\tdecision\n')
        for r in res:
            for k,m in r['m'].items():
                if m['st']=='R':
                    c=[m['best']]+m['alt']; c+= [None]*(3-len(c))
                    f.write('\t'.join([str(r['i']),k,r['t'][:300]]+[(x['t'][:250]+f" (ص {x['pg']})") if x else '' for x in c]+[''])+'\n')
    cnt={k:collections.Counter(r['m'][k]['st'] for r in res) for k in O}
    print(json.dumps(cnt,ensure_ascii=False))
if __name__=='__main__': main()
```

### scripts/apply_review.py
```python
#!/usr/bin/env python3
"""دمج قرارات المراجعة اليدوية في results.json.
python3 apply_review.py results.json decisions.txt
كل سطر في decisions.txt: id<TAB>book<TAB>رمز[<TAB>رقم المرشح 1-3]
الرموز: T متطابق، Q متقارب، K حكى خلافا، M مخالف، N غير مذكور.
ويجوز تصحيح أي وحدة ولو لم تكن في ملف المراجعة."""
import json,sys
R=json.load(open(sys.argv[1],encoding='utf-8'))
idx={r['i']:r for r in R['res']}; n=0
for ln in open(sys.argv[2],encoding='utf-8'):
    p=ln.rstrip('\n').split('\t')
    if len(p)<3 or not p[0].isdigit(): continue
    m=idx[int(p[0])]['m'][p[1]]; m['st']=p[2].strip(); m['manual']=True; n+=1
    if len(p)>3 and p[3].strip() in '23' and m['alt']:
        k=int(p[3])-1
        if k<=len(m['alt']): m['best'],m['alt'][k-1]=m['alt'][k-1],m['best']
left=sum(1 for r in R['res'] for m in r['m'].values() if m['st']=='R')
json.dump(R,open(sys.argv[1],'w',encoding='utf-8'),ensure_ascii=False)
print('طُبّق',n,'قرارًا؛ بقي بلا مراجعة:',left)
```

### scripts/report.py
```python
#!/usr/bin/env python3
"""إخراج النتائج: كتاب كامل، أو تقرير مختصر، أو ملخص للمحادثة.
python3 report.py results.json --mode full|short|chat --base-name "زاد المستقنع" --names "A=المقنع" --names "B=الوجيز"
   --title "..." --author "..." [--credit "..."] [--out out_dir] [--pdf]
يحتاج: python-docx, matplotlib (ويفضل arabic-reshaper و python-bidi إن ظهرت الحروف مقطعة)، و LibreOffice لتحويل PDF."""
import json,argparse,collections,os,subprocess,statistics
ap=argparse.ArgumentParser()
ap.add_argument('results'); ap.add_argument('--mode',default='short'); ap.add_argument('--base-name',default='الكتاب الأساس')
ap.add_argument('--names',action='append',default=[]); ap.add_argument('--title',default='مقارنة بين الكتب'); ap.add_argument('--author',default='')
ap.add_argument('--credit',default=''); ap.add_argument('--out',default='out'); ap.add_argument('--pdf',action='store_true')
ap.add_argument('--method',default='')
a=ap.parse_args()
D=json.load(open(a.results,encoding='utf-8')); R=D['res']; K=D['others']
NM={k:k for k in K}; NM.update(dict(x.split('=',1) for x in a.names))
CAT=['T','Q','K','M','N','R']; CN={'T':'متطابق','Q':'متقارب','K':'حكى خلافًا','M':'مخالف','N':'غير مذكور','R':'لم يراجع'}
SYM={'T':'ت','Q':'ق','K':'خ','M':'م','N':'—','R':'؟'}
COL={'T':'#1b7a52','Q':'#5fbf8a','K':'#e0a526','M':'#c4402f','N':'#9b9b9b','R':'#d0d0d0'}
AR=lambda s: str(s).translate(str.maketrans('0123456789.','٠١٢٣٤٥٦٧٨٩٫'))
P=lambda x,n: AR(f'{x*100/n:.1f}')+'٪' if n else '—'
n=len(R); agree=lambda s: s in 'TQ'
st=lambda r,k: r['m'][k]['st']
cnt={k:collections.Counter(st(r,k) for r in R) for k in K}
allag=sum(1 for r in R if all(agree(st(r,k)) for k in K))
noneag=sum(1 for r in R if not any(agree(st(r,k)) for k in K))
sim={k:statistics.mean(min(1,r['m'][k]['best']['sc']) if r['m'][k]['best'] else 0 for r in R)*100 for k in K}
secs=list(dict.fromkeys(r['sec'] or '—' for r in R))
os.makedirs(a.out,exist_ok=True)
if a.mode=='chat':
    print(f'## نتائج مقارنة «{a.base_name}» بـ'+'، '.join(f'«{NM[k]}»' for k in K)+f'\n\nعدد وحدات الأساس: {n}\n')
    print('| الحال | '+' | '.join(NM[k] for k in K)+' |\n|---|'+'---|'*len(K))
    for c in CAT:
        if any(cnt[k][c] for k in K): print(f'| {CN[c]} | '+' | '.join(f'{cnt[k][c]} ({cnt[k][c]*100/n:.1f}٪)' for k in K)+' |')
    print(f'\n- وافق الأساسُ الكتبَ كلها في {allag} وحدة ({allag*100/n:.1f}٪)، ولم يوافق أيًّا منها في {noneag} ({noneag*100/n:.1f}٪).')
    for k in K: print(f'- متوسط التشابه اللفظي مع «{NM[k]}»: {sim[k]:.1f}٪')
    raise SystemExit
# ---------- charts
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
for f in ('/root/.fonts/Amiri-Regular.ttf','/usr/share/fonts/truetype/amiri/Amiri-Regular.ttf'):
    if os.path.exists(f): fm.fontManager.addfont(f); plt.rcParams['font.family']='Amiri'
try:
    import arabic_reshaper; from bidi.algorithm import get_display
    SHAPE=os.environ.get('SHAPE')=='1'
except ImportError: SHAPE=False
A=(lambda s: get_display(arabic_reshaper.reshape(str(s)))) if SHAPE else str
def stacked(fn,labels,rows,h):
    fig,ax=plt.subplots(figsize=(9,h)); left=[0]*len(labels)
    for c in CAT:
        v=[r[c] for r in rows]
        if not any(v): continue
        ax.barh(range(len(labels)),v,left=left,color=COL[c],edgecolor='white',height=.6,label=A(CN[c]))
        for i,(l,x) in enumerate(zip(left,v)):
            if x>=6: ax.text(l+x/2,i,AR(f'{x:.0f}'),ha='center',va='center',fontsize=9,color='white' if c in 'TKM' else '#111')
        left=[p+q for p,q in zip(left,v)]
    ax.set_yticks(range(len(labels))); ax.set_yticklabels([A(l) for l in labels]); ax.invert_yaxis(); ax.set_xlim(0,100)
    ax.xaxis.set_major_formatter(lambda x,p: AR(int(x))+'٪'); ax.spines[['top','right']].set_visible(False)
    ax.legend(ncol=5,loc='upper center',bbox_to_anchor=(.5,1.0+1.2/h/2+.08),frameon=False,fontsize=10)
    fig.tight_layout(); fig.savefig(fn,dpi=180); plt.close()
pct=lambda rows,k:{c:sum(1 for r in rows if st(r,k)==c)*100/max(1,len(rows)) for c in CAT}
stacked(f'{a.out}/c1.png',[NM[k] for k in K],[pct(R,k) for k in K],1.4+0.6*len(K))
FIG=[('c1.png','حال وحدات «'+a.base_name+'» في كل كتاب')]
if len(secs)>1 and a.mode=='full':
    for k in K:
        stacked(f'{a.out}/s_{k}.png',secs,[pct([r for r in R if (r['sec'] or '—')==s],k) for s in secs],max(3,0.42*len(secs)+1.5))
fig,ax=plt.subplots(figsize=(9,3))
for k,c in zip(K,['#1F4E3D','#B08D3C','#2a78d6','#6250d6']):
    ax.hist([min(1,r['m'][k]['best']['sc']) if r['m'][k]['best'] else 0 for r in R],bins=20,range=(0,1),histtype='step',lw=2,color=c,label=A(NM[k]))
ax.xaxis.set_major_formatter(lambda x,p: AR(int(x*100))+'٪'); ax.legend(frameon=False); ax.spines[['top','right']].set_visible(False)
ax.set_xlabel(A('درجة التشابه اللفظي')); fig.tight_layout(); fig.savefig(f'{a.out}/c2.png',dpi=180); plt.close()
FIG.append(('c2.png','توزيع درجات التشابه اللفظي'))
# ---------- docx
from docx import Document
from docx.shared import Pt,Cm,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
GREEN=RGBColor(0x1F,0x4E,0x3D); GOLD=RGBColor(0xB0,0x8D,0x3C); FONT='Traditional Arabic'
doc=Document()
for s in doc.sections: s.top_margin=s.bottom_margin=Cm(2.5); s.left_margin=s.right_margin=Cm(2.3)
def rtl_p(p):
    pPr=p._p.get_or_add_pPr(); b=OxmlElement('w:bidi'); pPr.append(b)
def runf(r,size=14,bold=False,color=None):
    r.font.name=FONT; r.font.size=Pt(size); r.bold=bold
    rPr=r._r.get_or_add_rPr(); f=rPr.find(qn('w:rFonts'))
    if f is None: f=OxmlElement('w:rFonts'); rPr.append(f)
    for at in ('w:ascii','w:hAnsi','w:cs'): f.set(qn(at),FONT)
    sz=OxmlElement('w:szCs'); sz.set(qn('w:val'),str(int(size*2))); rPr.append(sz)
    if bold: rPr.append(OxmlElement('w:bCs'))
    rPr.append(OxmlElement('w:rtl'))
    if color: r.font.color.rgb=color
def para(text,size=14,bold=False,color=None,align='j',after=6):
    p=doc.add_paragraph(); rtl_p(p); p.paragraph_format.space_after=Pt(after)
    p.alignment={'j':WD_ALIGN_PARAGRAPH.JUSTIFY,'c':WD_ALIGN_PARAGRAPH.CENTER,'r':WD_ALIGN_PARAGRAPH.RIGHT}[align]
    runf(p.add_run(text),size,bold,color); return p
def head(text,lvl=1):
    p=doc.add_heading(level=lvl); rtl_p(p); p.alignment=WD_ALIGN_PARAGRAPH.RIGHT if lvl>1 else WD_ALIGN_PARAGRAPH.CENTER
    runf(p.add_run(text),22 if lvl==1 else 17,True,GREEN)
def shade(cell,fill):
    tcPr=cell._tc.get_or_add_tcPr(); s=OxmlElement('w:shd'); s.set(qn('w:val'),'clear'); s.set(qn('w:fill'),fill); tcPr.append(s)
def table(hdr,rows,widths=None,size=11):
    t=doc.add_table(rows=1,cols=len(hdr)); t.style='Table Grid'
    tblPr=t._tbl.tblPr; b=OxmlElement('w:bidiVisual'); tblPr.append(b)
    for i,h in enumerate(hdr):
        c=t.rows[0].cells[i]; shade(c,'1F4E3D'); p=c.paragraphs[0]; rtl_p(p); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; runf(p.add_run(h),size,True,RGBColor(255,255,255))
    for ri,row in enumerate(rows):
        cs=t.add_row().cells
        for i,v in enumerate(row):
            p=cs[i].paragraphs[0]; rtl_p(p); p.alignment=WD_ALIGN_PARAGRAPH.CENTER if len(str(v))<14 else WD_ALIGN_PARAGRAPH.RIGHT
            runf(p.add_run(str(v)),size); shade(cs[i],'F6F0E1' if ri%2==0 else 'FBF8F0')
    if widths:
        for row in t.rows:
            for c,w in zip(row.cells,widths): c.width=Cm(w)
    doc.add_paragraph()
# cover
para(a.title,30,True,GREEN,'c',12); para(a.base_name+' مقارنًا بـ'+' و'.join('«'+NM[k]+'»' for k in K),18,True,GOLD,'c',30)
if a.author: para('إعداد',13,False,None,'c',2); para(a.author,18,True,GREEN,'c',4)
if a.credit: para(a.credit,12,False,None,'c',20)
doc.add_page_break()
if a.mode=='full':
    head('المقدمة'); para(f'هذه مقارنة بين «{a.base_name}» و'+'، و'.join('«'+NM[k]+'»' for k in K)+f'، تتبعت فيها {AR(n)} وحدة من وحدات الأساس في '+('كل كتاب منها' if len(K)>1 else 'الكتاب الآخر')+'، وقست درجة التطابق بينها بالأعداد والنسب والرسوم.')
    head('منهج العمل',2)
    for i,s in enumerate([x for x in (a.method.split('||') if a.method else [
        'استُخرج نص الكتب من ملفاتها، وجُرّد من التشكيل وأرقام الحواشي، وقُسّم إلى عبارات مع أرقام صفحاتها.',
        'استُعين في المقارنة والإحصاء بالنموذج الذكي «Claude» من شركة Anthropic، فقورنت كل عبارة من الأساس بعبارات كل كتاب ببرنامج يقيس اشتراك الألفاظ وتتابعها، واختير أقرب موضع لها مع درجة تشابه من صفر إلى مئة.',
        'ما كانت درجته منخفضة روجع موضعًا موضعًا مع أقرب ثلاثة مواضع إليه، وما فوق ذلك صُنّف آليًّا: متطابق إذا بلغ ٧٠٪، ومتقارب فيما دونه، ويُعدّ مما حكى فيه الخلاف إذا ذُكر في الموضع نفسه خلاف.',
        'ثم روجعت النتائج وأُقرّت.']) if x]): para(AR(i+1)+'- '+s)
    head('مصطلحات التصنيف',2)
    table(['الرمز','الحال'],[[SYM[c],CN[c]] for c in 'TQKMN'],[3,6])
    doc.add_page_break()
head('النتائج العامة' if a.mode=='full' else 'النتائج')
rows=[[CN[c]]+[f'{AR(cnt[k][c])} ({P(cnt[k][c],n)})' for k in K] for c in CAT if any(cnt[k][c] for k in K)]
rows.append(['الموافق في الحكم (ت+ق)']+[f'{AR(cnt[k]["T"]+cnt[k]["Q"])} ({P(cnt[k]["T"]+cnt[k]["Q"],n)})' for k in K])
table(['الحال']+[NM[k] for k in K],rows)
para(f'وافق «{a.base_name}» الكتب كلها في {AR(allag)} وحدة ({P(allag,n)})، ولم يوافق أيًّا منها بنصه في {AR(noneag)} وحدة ({P(noneag,n)}). ومتوسط التشابه اللفظي: '+'، '.join(f'مع «{NM[k]}» {AR(f"{sim[k]:.1f}")}٪' for k in K)+'.')
for fn,cap in FIG:
    doc.add_picture(f'{a.out}/{fn}',width=Cm(16)); doc.paragraphs[-1].alignment=WD_ALIGN_PARAGRAPH.CENTER; para('شكل: '+cap,11,True,None,'c',12)
if len(secs)>1:
    head('النتائج في كل قسم',2 if a.mode=='short' else 1)
    for k in K:
        para('مع «'+NM[k]+'»',15,True,GOLD,'r')
        table(['القسم','الوحدات']+[SYM[c] for c in 'TQKMN']+['الموافقة'],
              [[s,AR(len(G))]+[AR(sum(1 for r in G if st(r,k)==c)) for c in 'TQKMN']+[P(sum(1 for r in G if agree(st(r,k))),len(G))] for s in secs for G in [[r for r in R if (r['sec'] or '—')==s]]],[5.5,1.6]+[1.2]*5+[2],size=10)
        if a.mode=='full' and os.path.exists(f'{a.out}/s_{k}.png'):
            doc.add_picture(f'{a.out}/s_{k}.png',width=Cm(16)); doc.paragraphs[-1].alignment=WD_ALIGN_PARAGRAPH.CENTER
head('المواضع المخالفة',2 if a.mode=='short' else 1)
ML=[r for r in R if any(st(r,k)=='M' for k in K)]
if ML: table(['عبارة '+a.base_name]+[NM[k] for k in K],[[f"{r['t']} (ص {AR(r['pg'])})"]+[(f"{r['m'][k]['best']['t']} (ص {AR(r['m'][k]['best']['pg'])})" if st(r,k)=='M' else SYM[st(r,k)]) for k in K] for r in ML],size=10)
else: para('لا توجد مواضع حُكم عليها بالمخالفة.')
if a.mode=='full':
    doc.add_page_break(); head('جدول التتبع'); para('أمام كل وحدة من الأساس صفحتها، ثم حالها ورقم صفحتها في كل كتاب. الرموز: ت متطابق، ق متقارب، خ حكى خلافًا، م مخالف، — غير مذكور.')
    table(['م','العبارة','ص']+[x for k in K for x in (NM[k],'ص')],
        [[AR(i+1),r['t'][:120],AR(r['pg'])]+[x for k in K for x in (SYM[st(r,k)],AR(r['m'][k]['best']['pg']) if r['m'][k]['best'] and st(r,k)!='N' else '—')] for i,r in enumerate(R)],size=9)
    head('الخاتمة'); para('وما كان في هذا العمل من صواب فمن الله وحده، وما كان فيه من خطأ فمن نفسي ومن الشيطان.')
fn=f'{a.out}/{a.title}.docx'; doc.save(fn); print(fn)
if a.pdf:
    subprocess.run(['soffice','--headless','--convert-to','pdf','--outdir',a.out,fn],capture_output=True); print(fn[:-5]+'.pdf')
```
