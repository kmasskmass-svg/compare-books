#!/usr/bin/env python3
"""دمج قرارات المراجعة اليدوية في results.json.
python3 apply_review.py results.json decisions.txt
كل سطر في decisions.txt: id<TAB>book<TAB>رمز[<TAB>رقم المرشح 1-3]
الرموز: T متطابق، Q متقارب، K حكى خلافا، M مخالف، N غير مذكور.
ويجوز تصحيح أي وحدة ولو لم تكن في ملف المراجعة."""
import json,sys
R=json.load(open(sys.argv[1],encoding='utf-8'))
idx={r['i']:r for r in R['res']}; n=0
for ln in open(sys.argv[2],encoding='utf-8'):
    p=ln.rstrip('\n').split('\t')
    if len(p)<3 or not p[0].isdigit(): continue
    m=idx[int(p[0])]['m'][p[1]]; m['st']=p[2].strip(); m['manual']=True; n+=1
    if len(p)>3 and p[3].strip() in '23' and m['alt']:
        k=int(p[3])-1
        if k<=len(m['alt']): m['best'],m['alt'][k-1]=m['alt'][k-1],m['best']
left=sum(1 for r in R['res'] for m in r['m'].values() if m['st']=='R')
json.dump(R,open(sys.argv[1],'w',encoding='utf-8'),ensure_ascii=False)
print('طُبّق',n,'قرارًا؛ بقي بلا مراجعة:',left)
